const express = require("express");
const app = express();
const port = 3004
const mysql = require("./connection").con
const bp = require('body-parser')

//swagger
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
//configuration
app.set("view engine", "hbs")
app.set("views", "./view")
app.use(express.static(__dirname + "/public"))

app.use(bp.json())
app.use(bp.urlencoded({ extended: true }))

app.post("/create", (req, res) => {
    // fetching data from form
    const { Name, Age, Email, Gender, MobileNumber, Birthday,
        City, State, Country, Address1, Address2 } = req.query
        if (Age<=18){
            app.use('/', (req, res,next)=>{
            res.json({code:400, message: 'Bad request' , error:'Age restricted', data: null})
            });
            return
        }
        else if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(Email)){
            app.use('/', (req, res,next)=>{
            res.json({code:400, message: 'Bad request' , error:'email not valid', data: null})
            });
            return
        }
        else if(!/^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/.test(Birthday)){
            app.use('/', (req, res,next)=>{
            res.json({code:400, message: 'Bad request' , error:'birthday format not valid', data: null}) 
            });
            return
        }
        else if(!/\d{10}/.test(MobileNumber)){
            app.use('/', (req, res,next)=>{
            res.json({code:400, message: 'Bad request' , error:'mobilenumber not valid', data: null}) 
            });
            return
        }

    let qry2 = "insert into Profile values(?,?,?,?,?,?,?,?,?,?,?)";
    let date = Birthday.split('/')
    let finaldate = date[2]+'/'+date[1]+'/'+date[0]
    mysql.query(qry2, [Name, Age, Email, Gender, MobileNumber, finaldate,
        City, State, Country, Address1, Address2], (err, results) => {
            console.log(err, results)
            if (results.affectedRows > 0) {
                res.json({code:200, message: 'User created successfully', error: false, data: results})
            }
            else{
                res.json({code:400, message: 'User not created' , error:err?.message, data: null})
            }
        })


});
app.get("/read", (req, res) => {
    // fetching data from form
    const {Age} = req.query
        if (Age<=18){
            res.json({code:400, message: 'Bad request' , error:'Age restricted', data: null})
        }

    let qry2 = "select * from Profile Where Age>=?";
    mysql.query(qry2, [Age], (err, results) => {
            console.log(err, results)
            if (err==null) {
                res.json({code:200, message: 'User read successfully', error: false, data: results})
            }
            else{
                res.json({code:400, message: 'User not read' , error:err?.message, data: null})
            }
        })


});
app.put("/update", (req, res) => {
    // fetch data

    const { Name, Gender, MobileNumber } = req.body.data;
    console.log(req.data);
    let qry2 = "select * from Profile Where Name=?";
    mysql.query(qry2, [Name,Gender, MobileNumber], (err, results) => {
            console.log(err, results)
            if (results.length>0) {
                let qry = "update Profile set MobileNumber=? where Name=?";
                mysql.query(qry, [MobileNumber,Name], (err, results) => {
                    if (err) throw err
                    else {
                        if (err==null) {
                           
                            res.json({code:200, message: 'User Updated successfully', error: false, data: results})
                          
                        }
                        else{
                            
                            res.json({code:400, message: 'User not updated' , error:err?.message, data: null})
                           
                        }
                    }
                })
            }
            else{
                
                res.json({code:400, message: 'User not found' , error:err?.message, data: null})
               
            }
        })


});
app.delete("/remove", (req, res) => {

    // fetch data from the form


    const { MobileNumber } = req.query;

    let qry = "delete from Profile where MobileNumber=?";
    mysql.query(qry, [MobileNumber], (err, results) => {
        if (err) throw err
        else {
            if (err==null) {
                res.json({code:200, message: 'User Deleted successfully', error: false, data: results})
            }
            else{
                res.json({code:400, message: 'User not deleted' , error:err?.message, data: null})
            }
            
        }
    });
});
//Create Server
app.listen(port, (err) => {
    if (err)
        throw err
    else
        console.log("Server is running at port %d:", port);
});